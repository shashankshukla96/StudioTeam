const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const multer = require('multer');


const EducatorsController = require('../controllers/educators');
const Educator = require('../models/educator');

const storage = multer.diskStorage({
    destination : function (req, file, cb){
        let path1 = "C:\\Users\\shashank.shukla01\\Desktop\\educator-script-approval-infy-master\\educator-script-approval-infy-master\\uploads\\"
        cb(null, path1);
    },
    filename : function (req, file, cb){
        console.log("ned da: "+new Date().toISOString());
        let fileNameArr = file.originalname.split('.')
        cb(null, String(path)+'.'+ fileNameArr[fileNameArr.length - 1]);
    }
});
const fileFilter = (req, file, cb) =>{
    if( file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
        cb(null, true);
    }
    else{
        cb(null, false);
    }
};

const upload = multer({
    storage : storage, 
    limits : {
    fileSize : 1024 * 1024 * 5
    },
    fileFilter : fileFilter
});

const createReqId = (req, res, next)=>{
    req.body.reqid = new Date().getTime();
    path = req.body.reqid
    next();
}

router.post('/',[createReqId,  upload.single('script'),EducatorsController.educator_create_request]);
router.get('/',EducatorsController.educator_get_all);
router.get('/:name', EducatorsController.educator_get_one);
router.patch('/:reqid', EducatorsController.educator_request_status_patch);
router.get('/download/path',(req, res, next)=>{
    console.log(req.query)
    const path = 'C:\\Users\\shashank.shukla01\\Desktop\\sso-master\\educator-script-approval-infy-master\\uploads\\1564399660490.png'
    res.download(req.query.path);
})

module.exports = router;
