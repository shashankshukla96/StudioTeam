var request = new XMLHttpRequest();
request.open('GET', 'http://localhost:3000/educators', true);
request.onload = function () {

  // Begin accessing JSON data here
  data = JSON.parse(this.response);
  root = document.getElementById("root");
    
  console.log(data.count);
  if (request.status >= 200 && request.status < 400) {
 
    for(let i= 0 ; i < data.count ; i ++)
    {
        if(data.educators[i].status != -1 )
        {
            let html = "<div class='custom-card col-lg-3 m-2 p-0 shadow'>";
            html += "<div class='card-info'>";
            html += "<h4>" + data.educators[i].reqid + "</h4>"
            html += "<span class='mt-3'>"
            html += "<h6 class='pr-2'>" + data.educators[i].title + "</h6>"
            html += "<h6 class='pl-2'> " + (new Date(data.educators[i].reqid)).toDateString() + "</h6>"
            html += "</span>"
            html += "<div class='progress'>"
            // console.log(data.educators[i].status);
            for(let j = 1 ; j <= data.educators[i].status ; j ++)
            {
                console.log(i, data.educators[i].status);
                html += "<div class='progress-bar bg-success' role='progressbar' style='width: 25%' aria-valuenow='15' aria-valuemin='0' aria-valuemax='100'></div>&nbsp;"
            }
            for(let j = 4 ; j > data.educators[i].status ; j --)
            {
                html += "<div class='progress-bar bg-danger' role='progressbar' style='width: 25%' aria-valuenow='15' aria-valuemin='0' aria-valuemax='100'></div>&nbsp;"
            }

            let status = "";
            if(data.educators[i].status == 0)
            {
                status = "Pending for Script Approval"
            }
            else if(data.educators[i].status == 1)
            {
                status = "Script Approved, Book a slot to shoot Video."
            }
            else if(data.educators[i].status == 2)
            {
                status = "Video Shooting Done!. Pending for Editing."
            }
            else if(data.educators[i].status == 3)
            {
                status = "Video Ready, Pending for Approval."
            }
            else if(data.educators[i].status == 4)
            {
                status = "Video Approved."
            }
            else if(data.educators[i].status == -1)
            {
                status = "Rejected."
            }
            html += "</div>            </div>"
            html += "<div class='card-meta'>"
            html += "<p class='m-0'>"+ status +"</p>"
            html += "<div class='btn-group dropup'>"
            html += "<i class='material-icons dropdown-toggle' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>more_vert</i>"
            html += "<div class='dropdown-menu dropdown-menu-lg-left'>"
            html += "<a class='dropdown-item open-btn' href='#' data-toggle='modal' onclick='func("+i+")' data-target='#exampleModalScrollable'>Open</a>"
            html += "<a class='dropdown-item' href='#'>Another action</a>"
            html += "<a class='dropdown-item' href='#'>Something else here</a>"
            html += "</div></div></div></div>";

            root.innerHTML += html;
        }
    }
} else {
    console.log("error");
  }
}
request.send();

function func(id) {
    console.log(id);
    $("#modal-emp-id").text(data.educators[id].reqid);
    $("#modal-emp-name").text(data.educators[id].name);
    $("#modal-title").text(data.educators[id].title);

    let status = "";
    if(data.educators[id].status == 0)
    {
        status = "Pending for Script Approval"
    }
    else if(data.educators[id].status == 1)
    {
        status = "Script Approved, Book a slot to shoot Video."
    }
    else if(data.educators[id].status == 2)
    {
        status = "Video Shooting Done!. Pending for Editing."
    }
    else if(data.educators[id].status == 3)
    {
        status = "Video Ready, Pending for Approval."
    }
    else if(data.educators[id].status == 4)
    {
        status = "Video Approved."
    }
    else if(data.educators[id].status == -1)
    {
        status = "Rejected."
    }

    $("#modal-date").text((new Date(data.educators[id].reqid)).toDateString());
    $("#modal-status").text(status);
    $("#modal-accept").attr("value", data.educators[id].reqid);
    $("#modal-reject").attr("value", data.educators[id].reqid);
    console.log(data.educators[id].comments)
    $("#modal-comments").val(data.educators[id].comments);

    var arr = data.educators[id].script.split('\\')
    console.log(arr[arr.length -1])
    var path = "../uploads/"+arr[arr.length -1]
    console.log(path)
    $("#fileRequest").attr('href', path)
}

function getData(filter)
{
    root.innerHTML = "";
    for(let i= 0 ; i < data.count ; i ++)
    {
        if(data.educators[i].status == filter)
        {
            let html = "<div class='custom-card col-lg-3 m-2 p-0 shadow'>";
            html += "<div class='card-info'>";
            html += "<h4>" + data.educators[i].reqid + "</h4>"
            html += "<span class='mt-3'>"
            html += "<h6 class='pr-2'>" + data.educators[i].title + "</h6>"
            html += "<h6 class='pl-2'> " + (new Date(data.educators[i].reqid)).toDateString() + "</h6>"
            html += "</span>"
            html += "<div class='progress'>"
            for(let j = 0 ; j < data.educators[i].status ; j ++)
            {
                html += "<div class='progress-bar bg-success' role='progressbar' style='width: 25%' aria-valuenow='15' aria-valuemin='0' aria-valuemax='100'></div>&nbsp;"
            }
            for(let j = 0 ; j < 4-data.educators[i].status ; j ++)
            {
                html += "<div class='progress-bar bg-primary' role='progressbar' style='width: 25%' aria-valuenow='15' aria-valuemin='0' aria-valuemax='100'></div>&nbsp;"
            }

            let status = "";
            if(data.educators[i].status == 0)
            {
                status = "Pending for Script Approval"
            }
            else if(data.educators[i].status == 1)
            {
                status = "Script Approved, Book a slot to shoot Video."
            }
            if(data.educators[i].status == 2)
            {
                status = "Video Shooting Done!. Pending for Editing."
            }
            if(data.educators[i].status == 3)
            {
                status = "Video Ready, Pending for Approval."
            }
            if(data.educators[i].status == 4)
            {
                status = "Video Approved."
            }
            if(data.educators[i].status == -1)
            {
                status = "Rejected."
            }
            html += "</div>            </div>"
            html += "<div class='card-meta'>"
            html += "<p class='m-0'>"+ status +"</p>"
            html += "<div class='btn-group dropup'>"
            html += "<i class='material-icons dropdown-toggle' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>more_vert</i>"
            html += "<div class='dropdown-menu dropdown-menu-lg-left'>"
            html += "<a class='dropdown-item open-btn' href='#' data-toggle='modal' onclick='func("+i+")' data-target='#exampleModalScrollable'>Open</a>"
            html += "<a class='dropdown-item' href='#'>Another action</a>"
            html += "<a class='dropdown-item' href='#'>Something else here</a>"
            html += "</div></div></div></div>";

            root.innerHTML += html;

        }
    }
}

function pre_prod() {
    console.log("pre_prod");
    getData(1);
}

function prod() {
    console.log("prod");
    getData(2);
}

function post_prod() {
    console.log("post_prod");
    getData(3);
}
function accepted() {
    console.log("Accepted");
    getData(4);
}
function rejected() {
    console.log("Rejected");
    getData(-1);
}


function find(id) {
    console.log(data.educators)
    for(var i = 0 ; i < data.count ; i ++)
    {
        if(data.educators[i].reqid == id)
            return i;
    }
}

$("#modal-accept").click(()=>{
    let id = $("#modal-accept").attr("value");

    let index = find(id);
    
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "http://localhost:3000/educators/"+id,
        "method": "PATCH",
        "headers": {
          "Content-Type": "application/json",
          "cache-control": "no-cache",
          "Postman-Token": "fc854b13-1fc1-405c-9e08-f36ba6355f2c"
        },
        "processData": false,
        "data": "[{\"propName\" :\"status\", \"value\": "+(data.educators[index].status+1)+"}]"
      }
      
      $.ajax(settings).done(function (response) {
        console.log(response);
      });


      location.href = "http://127.0.0.1:5500/view/design-team.html";
})


$("#modal-reject").click(()=>{
    let id = $("#modal-accept").attr("value");

    let index = find(id);
    
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "http://localhost:3000/educators/"+id,
        "method": "PATCH",
        "headers": {
          "Content-Type": "application/json",
          "cache-control": "no-cache",
          "Postman-Token": "fc854b13-1fc1-405c-9e08-f36ba6355f2c"
        },
        "processData": false,
        "data": "[{\"propName\" :\"status\", \"value\": "+(-1)+"}]"
      }
      
      $.ajax(settings).done(function (response) {
        console.log(response);
      });

      location.href = "http://127.0.0.1:5500/view/design-team.html";
})


// function downloadFile(){
//     var e = $("#fileRequest").val()
//     console.log(e)




//     var settings = {
//         "async": true,
//         "crossDomain": true,
//         "url": "http://localhost:3000/educators/download/path?path="+e,
//         "method": "GET",

//         "processData": false,
//         // "data": "[{\"propName\" :\"status\", \"value\": "+(-1)+"}]"
//       }
      
//       $.ajax(settings).done(function (response) {
//         // console.log(response);
//       });

// }