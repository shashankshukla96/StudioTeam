var express = require('express')
var app = express()
var server = require('http').createServer(app)
var cors = require('cors')
var nodeSSPI = require('node-sspi')
var bodyParser= require('body-parser')
// Add frontend server address
var corsOptions = {
  origin: ['http://127.0.0.1:5500'],
  optionsSuccessStatus: 200,
  credentials:true
}
app.use(bodyParser.urlencoded({ extended: true }))
  
app.use("/",cors(corsOptions),function (req, res, next) {
  var nodeSSPIObj = new nodeSSPI({
    retrieveGroups: true  
  })
//method to authenticate the logged in user
  nodeSSPIObj.authenticate(req, res, function(err){     
    res.finished || next() 
       
  })
})
app.use(cors(corsOptions),function(req, res, next) {
  userName = req.connection.user
  if(userName){
  uName = userName.substr(11,) // to display only the user name
  var out = {}
  out["username"] = uName;
}
  let whiteList = ["chebolu.saiguptha", 'deepak_m05', "shashank.shukla01"];
  if(whiteList.includes(out.username)){
    out.access = true
  }else{
    out.access = false;
  }
  res.send(JSON.stringify(out))

})
server.listen(3080, function () {
  console.log('Express server listening on port 3080')
})