var request = new XMLHttpRequest();

let un = sessionStorage.getItem('userName')
request.open('GET', 'http://localhost:3000/educators/'+un, true);
request.onload = function () {

  // Begin accessing JSON data here
  data = JSON.parse(this.response);
  root = document.getElementById("wrapper-dock");
    
  console.log(data);
  if (request.status >= 200 && request.status < 400) {
 
    for(let i= 0 ; i < data.count ; i ++)
    {
        if(true)
        {
            let html = "<div class='custom-card'>";
            html += "<div class='card-info'>";
            html += "<h4>" + data.educators[i].reqid + "</h4>"
            html += "<span class='mt-3'>"
            html += "<h6 class='pr-2'>" + data.educators[i].title + "</h6>"
            html += "<h6 class='pl-2'> " + (new Date(data.educators[i].reqid)).toDateString() + "</h6>"
            html += "</span>"
            html += "<div class='progress'>"
            // console.log(data.educators[i].status);
            for(let j = 1 ; j <= data.educators[i].status ; j ++)
            {
                console.log(i, data.educators[i].status);
                html += "<div class='progress-bar bg-success' role='progressbar' style='width: 25%' aria-valuenow='15' aria-valuemin='0' aria-valuemax='100'></div>&nbsp;"
            }
            for(let j = 4 ; j > data.educators[i].status ; j --)
            {
                html += "<div class='progress-bar bg-primary' role='progressbar' style='width: 25%' aria-valuenow='15' aria-valuemin='0' aria-valuemax='100'></div>&nbsp;"
            }

            let status = "";
            if(data.educators[i].status == 0)
            {
                status = "Pending for Script Approval"
            }
            else if(data.educators[i].status == 1)
            {
                status = "Script Approved, Book a slot to shoot Video."
            }
            else if(data.educators[i].status == 2)
            {
                status = "Video Shooting Done!. Pending for Editing."
            }
            else if(data.educators[i].status == 3)
            {
                status = "Video Ready, Pending for Approval."
            }
            else if(data.educators[i].status == 4)
            {
                status = "Video Approved."
            }
            else if(data.educators[i].status == -1)
            {
                status = "Rejected."
            }
            html += "</div>            </div>"
            html += "<div class='card-meta'>"
            html += "<p class='m-0'>"+ status +"</p>"
            html += "<a class='btn-pop-up' href='' target='' rel='noopener noreferrer' data-toggle='modal' data-target='#infoModal'><i class='material-icons' onclick='func("+i+")'>arrow_right_alt</i></a>"
            html += "</div></div>";

            root.innerHTML += html;
        }
    }
} else {
    console.log("error");
  }
}
request.send();

function func(id) {
    console.log(id);
    $("#modal-emp-id").text(data.educators[id].reqid);
    // $("#modal-emp-name").text(data.educators[id].name);
    $("#modal-title").text(data.educators[id].title);

    let status = "";
    if(data.educators[id].status == 0)
    {
        status = "Pending for Script Approval"
    }
    else if(data.educators[id].status == 1)
    {
        status = "Script Approved, Book a slot to shoot Video."
    }
    else if(data.educators[id].status == 2)
    {
        status = "Video Shooting Done!. Pending for Editing."
    }
    else if(data.educators[id].status == 3)
    {
        status = "Video Ready, Pending for Approval."
    }
    else if(data.educators[id].status == 4)
    {
        status = "Video Approved."
    }
    else if(data.educators[id].status == -1)
    {
        status = "Rejected."
    }

    $("#modal-date").text((new Date(data.educators[id].reqid)).toDateString());
    $("#modal-status").text(status);
   
    console.log(data.educators[id].comments)
    $("#modal-comments").text(data.educators[id].comments);
}

function getData(filter)
{
    root.innerHTML = "";
    for(let i= 0 ; i < data.count ; i ++)
    {
        if(data.educators[i].status == filter)
        {
            let html = "<div class='custom-card col-lg-3 m-2 p-0 shadow'>";
            html += "<div class='card-info'>";
            html += "<h4>" + data.educators[i].reqid + "</h4>"
            html += "<span class='mt-3'>"
            html += "<h6 class='pr-2'>" + data.educators[i].title + "</h6>"
            html += "<h6 class='pl-2'> " + (new Date(data.educators[i].reqid)).toDateString() + "</h6>"
            html += "</span>"
            html += "<div class='progress'>"
            for(let i = 0 ; i < data.educators[i].status ; i ++)
            {
                html += "<div class='progress-bar bg-success' role='progressbar' style='width: 25%' aria-valuenow='15' aria-valuemin='0' aria-valuemax='100'></div>&nbsp;"
            }
            for(let i = 0 ; i < 4-data.educators[i].status ; i ++)
            {
                html += "<div class='progress-bar bg-primary' role='progressbar' style='width: 25%' aria-valuenow='15' aria-valuemin='0' aria-valuemax='100'></div>&nbsp;"
            }

            let status = "";
            if(data.educators[i].status == 0)
            {
                status = "Pending for Script Approval"
            }
            else if(data.educators[i].status == 1)
            {
                status = "Script Approved, Book a slot to shoot Video."
            }
            if(data.educators[i].status == 2)
            {
                status = "Video Shooting Done!. Pending for Editing."
            }
            if(data.educators[i].status == 3)
            {
                status = "Video Ready, Pending for Approval."
            }
            if(data.educators[i].status == 4)
            {
                status = "Video Approved."
            }
            html += "</div>            </div>"
            html += "<div class='card-meta'>"
            html += "<p class='m-0'>"+ status +"</p>"
            html += "<div class='btn-group dropup'>"
            html += "<i class='material-icons dropdown-toggle' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>more_vert</i>"
            html += "<div class='dropdown-menu dropdown-menu-lg-left'>"
            html += "<a class='dropdown-item open-btn' href='#' data-toggle='modal' onclick='func("+i+")' data-target='#exampleModalScrollable'>Open</a>"
            html += "<a class='dropdown-item' href='#'>Another action</a>"
            html += "<a class='dropdown-item' href='#'>Something else here</a>"
            html += "</div></div></div></div>";

            root.innerHTML += html;

        }
    }
}


function clicked(){
    let name = $("#name").val()
    let title = $("#title").val()
    let location = $("#location").val()
    let file = $("#file")[0]
    console.log(name, title, location, file)

    var form = $("#req-form")[0];
    var formData = new FormData(form);

    $.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url: "http://localhost:3000/educators",
        data: formData,
        processData: false,
        contentType: false,
        cache: false,
        timeout: 600000,
        success: function (data) {

            // $("#result").text(data);
            console.log("SUCCESS : ", data);
            // $("#btnSubmit").prop("disabled", false);

        },
        error: function (e) {

            // $("#result").text(e.responseText);
            console.log("ERROR : ", e);
            // $("#btnSubmit").prop("disabled", false);

        }
    });
}